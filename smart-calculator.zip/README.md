# Smart Calculator

A simple calculator made using **HTML, CSS, and JavaScript**.

### 🌐 Live Hosting
You can host this on **GitHub Pages** or **Netlify** easily.

### ⚙️ Features
- Basic arithmetic operations
- Responsive design
- Clean UI

### 👨‍💻 How to Use
1. Upload files to GitHub.
2. Connect your repo to [Netlify](https://www.netlify.com/).
3. Deploy directly — no backend required!

---
Made with ❤️ by PRANAB BARUAH
